<?php
$payload = ['title' => 'Hello', 'body' => 'From PHP cURL', 'userId' => 1];

$ch = curl_init('https://jsonplaceholder.typicode.com/posts');
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_TIMEOUT => 10,
  CURLOPT_POST => true,
  CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
  CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE)
]);

$response = curl_exec($ch);
if ($response === false) {
  die('cURL error: ' . curl_error($ch));
}

$code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);

echo "HTTP: $code<br>";
echo "Response: <pre>" . htmlspecialchars($response) . "</pre>";
?>