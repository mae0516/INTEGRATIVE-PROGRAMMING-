<?php
$ch = curl_init('https://jsonplaceholder.typicode.com/posts/1');
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HEADER => true,
  CURLOPT_TIMEOUT => 10,
  CURLOPT_VERBOSE => true
]);

$raw = curl_exec($ch);
if ($raw === false) { die('cURL error: ' . curl_error($ch)); }

$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$headers = substr($raw, 0, $headerSize);
$body    = substr($raw, $headerSize);
$code    = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);

echo "<pre>HTTP $code\n$headers</pre>";
echo "<hr>";
echo "<pre>" . htmlspecialchars($body) . "</pre>";
?>