<?php
$data = ['name' => 'Juan', 'email' => 'juan@example.com'];
$options = [
  'http' => [
    'method'  => 'POST',
    'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
    'content' => http_build_query($data),
    'timeout' => 10
  ]
];

$ctx = stream_context_create($options);
$response = file_get_contents('https://jsonplaceholder.typicode.com/posts', false, $ctx);

if ($response === false) {
    echo "POST failed.";
    exit;
}
echo $response;
?>