<?php
$ch = curl_init('https://jsonplaceholder.typicode.com/posts/1');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$response = curl_exec($ch);
if ($response === false) {
    die('cURL error: ' . curl_error($ch));
}

$httpCode = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    die("HTTP $httpCode");
}

$data = json_decode($response);
echo "Title: " . htmlspecialchars($data->title) . "<br>";
echo "Body: " . nl2br(htmlspecialchars($data->body));
?>