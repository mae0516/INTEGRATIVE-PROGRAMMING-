<?php
$url = 'https://jsonplaceholder.typicode.com/posts/1';
$response = file_get_contents($url);

if ($response === false) {
    echo "Failed to fetch.";
    exit;
}

echo $response;
?>