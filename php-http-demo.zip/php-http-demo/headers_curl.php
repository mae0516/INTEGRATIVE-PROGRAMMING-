<?php
$token = 'YOUR_API_TOKEN'; // replace with real API token if needed
$ch = curl_init('https://jsonplaceholder.typicode.com/posts/2');
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => [
    'User-Agent: MyCustomApp/1.0',
    "Authorization: Bearer $token"
  ]
]);

$response = curl_exec($ch);
if ($response === false) { die(curl_error($ch)); }
echo $response;
curl_close($ch);
?>